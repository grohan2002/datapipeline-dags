import json
import psycopg2
from data_pipeline.config import conf
from datetime import datetime
from data_pipeline import logger
from data_pipeline.utils.pipeline_constants import EntityEnum

ID = 0


def connect_postgresql():
    """
    Connect to Postgresql db
    """
    postgresql_conf = conf.get("POSTGRESQL")
    connection = psycopg2.connect(
        host=postgresql_conf.get('host'),
        port=postgresql_conf.get('port'),
        user=postgresql_conf.get('user'),
        password=postgresql_conf.get('password'),
        database=postgresql_conf.get('database'),
    )
    return connection


def read_latest_postgres_data(connection, table_name, time_offset, last_row_id):
    """
    Fetch latest rows from postgresql to sync with mysql db

    Args:
        table_name (str): Name of Table
        time_offset (datetime): Latest processing timestamp
        last_row_id (int): Last inserted row id
    Returns (list):
        records - List of latest rows
    """
    select_query = generate_fetch_records_to_sync_query(last_row_id, table_name, time_offset)

    try:
        return execute_fetch_all(connection, select_query)
    except (Exception, psycopg2.DatabaseError) as error:
        logger.exception(f"Exception occurred while fetching data from Postgresql")


def execute_fetch_all(connection, select_query: str):
    """
    Function to execute postgresql query and return the result of the query as a list
    Args:
        select_query (str):

    Returns (list):

    """
    cursor = connection.cursor()
    logger.debug(f"Select Query --- {select_query}")
    cursor.execute(select_query)
    query_result = [
        dict(line)
        for line in [
            zip([column[0] for column in cursor.description], row) for row in cursor.fetchall()
        ]
    ]
    if cursor:
        cursor.close()
    return query_result


def generate_fetch_records_to_sync_query(last_row_id, table_name, time_offset):
    """
    Function to generate the query that will fetch latest records from postgresql db to sync with mysql db

    What the select_query does?
        Step 1: Select all the records from the `contacts` or `transactions` table where `processing_ts` and `id`
            are greater than given values
        Step 2: Generate a Rank of the records filtered in Step 1 by partitioning them on `company_id` and `external_id`
            and then ordering them in descending order by `input_file_creation_ts`, `processing_ts` and `id`
        Step 3: Filter out all the records where `rank is not 1` from the result in Step 2
        Step 4: (Only for `contacts` table) Perform a left outer join with the `verified_contacts` table on `company_id`
            and `external_id`
    Args:
        last_row_id (int):
        table_name (str):
        time_offset (datetime):

    Returns (str):
        Examples:
            with latest_contacts_rows as
            (
                select c_filter.*
                from (
                        select contacts.*,
                        rank() OVER (
                            partition by company_id, external_id
                            order by input_file_creation_ts desc, processing_ts desc, id desc
                        )
                        from contacts
                        where
                            processing_ts >= timestamp '2019-11-10 12:14:17'
                            and id > 32467
                    ) c_filter
                where rank = 1
            )
            select
                c.*,
                v.verified_data
            from latest_contacts_rows as c
            left outer join verified_contacts as v
                on c.company_id = v.company_id
                and c.external_id = v.external_id
    """
    last_row_filter = f'and id > {last_row_id} ' if last_row_id is not None else ''

    select_verified_data = ', v.verified_data' if table_name == EntityEnum.CONTACT.value else ''

    merge_verified_contacts = (
        f'''
            left outer join verified_{table_name} as v
            on c.company_id = v.company_id 
            and c.external_id = v.external_id
        '''
        if table_name == EntityEnum.CONTACT.value
        else ''
    )

    select_query = f'''
        with latest_{table_name}_rows as 
        (
            select c_filter.* 
            from (
                    select {table_name}.*,
                    rank() OVER (
                        partition by company_id, external_id
                        order by input_file_creation_ts desc, processing_ts desc, id desc
                    )
                    from {table_name}
                    where 
                        processing_ts >= timestamp '{time_offset}'
                        {last_row_filter}
                ) c_filter 
            where rank = 1 
        )
        select c.* {select_verified_data}
        from latest_{table_name}_rows as c
        {merge_verified_contacts}
    '''
    return select_query


def fetch_latest_completed_sync_ts(connection, entity_type):
    """
    Function to fetch latest processing timestamp from data_sync_stats table

    Args-
        entity_type: Entity Type (contact or transaction)

    Returns-
        processing_timestamp: Latest processing timestamp
        to_id: Object Id of last PostgreSQL document upserted into MySQL
    """
    try:
        sql_fetch_processing_ts = f"""
            SELECT processing_ts, 
                    to_id 
            FROM data_sync_stats
            WHERE entity_type='{entity_type}'
            ORDER BY processing_ts DESC LIMIT 1
        """
        record = execute_fetch_all(connection, sql_fetch_processing_ts)
        logger.info(f'Timestamp returned from data_sync_stats - {record}')
        return record[0]['processing_ts'], record[0]['to_id']
    except Exception as error:
        logger.exception('No timestamp returned from data_sync_stats table')
        return datetime.utcfromtimestamp(0), None


def upsert_into_data_sync_table(
    connection, dag_run_id, processing_ts, entity_type, records_count, from_id, to_id, status
):
    """
    Function to insert and update rows in data_sync_stats table

    Args-
        connection: Postgresql connection
        dag_run_id: DAG Run ID
        processing_ts: Processing timestamp
        entity_type: Entity Type
        records_count: Record Count
        from_id: Object Id of first PostgreSQL document
        to_id: Object Id of last PostgreSQL document
        status: Status

    Returns-
    """
    cursor = connection.cursor()
    try:
        global ID

        sql_upsert_query = """
            INSERT INTO data_sync_stats (dag_run_id, processing_ts, entity_type, records_count, from_id, to_id, status)
            VALUES(%, %,  %, %, %, %, %)
            ON CONFLICT ON CONSTRAINT uk_data_sync_stats
            DO UPDATE SET
                records_count = %, to_id = %, processing_ts = %, status = %
            RETURNING id;
        """
        query_params = (
            dag_run_id,
            processing_ts,
            entity_type,
            records_count,
            from_id,
            to_id,
            status,
            records_count,
            to_id,
            processing_ts,
            status,
        )
        cursor.execute(sql_upsert_query, query_params)
        ID = cursor.fetchone()[0]
        logger.info(f"ID ---- {ID}")
        connection.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        logger.exception(f'Exception while upserting into Postgresql data_sync_stats table!')
    finally:
        cursor.close()


def update_verified_data(
    connection, entity: str, company_id: int, external_id: str, verified_data: dict
):
    """
    Function to update verified data into postgresql table
    Args:
        connection:
        entity (str):
        company_id (int):
        external_id (str):
        verified_data (dict):

    Returns: None

    """
    cursor = connection.cursor()
    try:
        generate_verified_data_str = json.dumps(verified_data)

        sql_query = f'''
            INSERT INTO verified_{entity}(company_id, external_id, verified_data) 
            VALUES(%s, %s, %s)
            ON CONFLICT ON CONSTRAINT uk_verified_{entity}
            DO UPDATE SET 
                verified_data = verified_{entity}.verified_data::jsonb || %s::jsonb,
                last_updated_at = CURRENT_TIMESTAMP
        '''
        query_params = (
            company_id,
            external_id,
            generate_verified_data_str,
            generate_verified_data_str,
        )

        logger.debug(sql_query)
        cursor.execute(sql_query, query_params)
        connection.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        logger.exception(f'Exception while updating `verified_data` in `verified_{entity}` table!')
        return False
    finally:
        cursor.close()
        return True
