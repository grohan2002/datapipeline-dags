import mysql.connector
from data_pipeline.config import conf
from data_pipeline import logger


def create_connection():
    """
    Function to create a connection with SQL

    Args:

    Returns:
        db_connection - Database connection
    """
    sql_conf = conf.get('MYSQLDB')
    db_connection = mysql.connector.connect(
        host=sql_conf["host"],
        user=sql_conf["user"],
        passwd=sql_conf["password"],
        database=sql_conf["database"],
    )
    return db_connection


def upsert_data_upload_logs(**args):
    """
    Function to update data upload logs in sql

    Args:
        **args: Arbitrary Keyword Arguments

    Returns:

    """
    db_connection = conf['MYSQL_STATSDB_CONNECTION']
    db_cursor = db_connection.cursor()

    table_name = conf.get("MYSQLDB")["table"]
    from data_pipeline import config

    upsert_query = """INSERT INTO {table_name}
                    (
                        id,
                        company_id,
                        filename,
                        dag_run_id,
                        workflow_system_used,
                        mapper_used
                    )
                    VALUES 
                    (   
                         {ID},
                         {company_id},
                        '{filename}',
                        '{dag_run_id}',
                         {workflow_system_used},
                        '{mapper_used}'
                    )
                    ON DUPLICATE KEY UPDATE
                    status = '{status}'
                """.format(
        table_name=table_name,
        ID=config.ID,
        company_id=args.get('company_id'),
        filename=args.get('filename'),
        dag_run_id=config.dag_run_id,
        workflow_system_used=args.get('workflow_system_used'),
        mapper_used=args.get('mapper_used'),
        status=args.get('status'),
    )

    if args.get('updated_at', None):
        upsert_query = "{upsert_query}, updated_at = '{updated_at}'".format(
            upsert_query=upsert_query, updated_at=args.get('updated_at')
        )

    if args.get('ingester_completed_at', None):
        upsert_query = "{upsert_query}, ingester_completed_at = '{ingester_completed_at}'".format(
            upsert_query=upsert_query, ingester_completed_at=args.get('ingester_completed_at')
        )

    if args.get('status', None):
        upsert_query = "{upsert_query}, status = {status}".format(
            upsert_query=upsert_query, status=args.get('status')
        )

    if args.get('created_at', None):
        upsert_query = "{upsert_query}, created_at = '{created_at}'".format(
            upsert_query=upsert_query, created_at=args.get('created_at')
        )

    if args.get('ingester_started_at', None):
        upsert_query = "{upsert_query}, ingester_started_at = '{ingester_started_at}'".format(
            upsert_query=upsert_query, ingester_started_at=args.get('ingester_started_at')
        )

    if args.get('customers_count', None):
        upsert_query = "{upsert_query}, customers_count = {customers_count}".format(
            upsert_query=upsert_query, customers_count=args.get('customers_count')
        )

    if args.get('transactions_count', None):
        upsert_query = "{upsert_query}, transactions_count = {transactions_count}".format(
            upsert_query=upsert_query, transactions_count=args.get('transactions_count')
        )

    if args.get('error_message', None):
        upsert_query = "{upsert_query}, error_message = '{error_message}'".format(
            upsert_query=upsert_query, error_message=args.get('error_message')
        )

    if args.get('retry_count', None):
        upsert_query = "{upsert_query}, retry_count = {retry_count}".format(
            upsert_query=upsert_query, retry_count=args.get('retry_count')
        )

    if args.get('customers_error_count', None):
        upsert_query = "{upsert_query}, customers_error_count = {customers_error_count}".format(
            upsert_query=upsert_query, customers_error_count=args.get('customers_error_count')
        )

    if args.get('transactions_error_count', None):
        upsert_query = "{upsert_query}, transactions_error_count = {transactions_error_count}".format(
            upsert_query=upsert_query, transactions_error_count=args.get('transactions_error_count')
        )

    upsert_query = "{upsert_query} ;".format(upsert_query=upsert_query)

    logger.debug(f'DB Query - {upsert_query}')
    db_cursor.execute(upsert_query)
    db_connection.commit()
    logger.debug(f"Row count : {db_cursor.rowcount}")
    logger.debug(f"ID : {db_cursor.lastrowid}")
    if db_cursor.lastrowid is not None and db_cursor.lastrowid != 0:
        config.ID = db_cursor.lastrowid
