import mysql.connector
from datetime import datetime
from functools import partial
from data_pipeline import logger
from data_pipeline.config import conf
from data_pipeline.utils.pipeline_constants import SyncStatusEnum
from data_pipeline.db.postgresql import upsert_into_data_sync_table


def connect_mysql():
    """
    Function to create a connection with MySQL DB
    Args:
    Returns:
        db_connection - Database connection
    """
    sql_conf = conf.get('MYSQLDB')
    db_connection = mysql.connector.connect(
        host=sql_conf["host"],
        user=sql_conf["user"],
        passwd=sql_conf["password"],
        database=sql_conf["database"],
    )
    logger.info('MySQL DB connection established!')
    return db_connection


def execute_fetch_one(connection, sql_query):
    try:
        cursor = connection.cursor(buffered=True)
        cursor.execute(sql_query)
        record = cursor.fetchone()
        cursor.close()
        return record
    except mysql.connector.Error as error:
        logger.exception(f"Error while connecting to MySQL due to connection error")


def mysql_insert_contacts(connection, postgres_connection, records: list, dag_run_id):
    try:
        cursor = connection.cursor(prepared=True)

        sql_upsert_query = """
            INSERT INTO `contact`
            (external_id, company_id, first_name, last_name, full_name, phone_daytime, phone_mobile, email, address1, 
            address2, city, state, zip, country, notes, wants_emails, wants_sms, wants_calls, wants_direct_mail, status)
            VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                first_name=%s, last_name=%s, full_name=%s, phone_daytime=%s, phone_mobile=%s, email=%s, address1=%s,
                address2=%s, city=%s, state=%s, zip=%s, country=%s, notes=%s, wants_emails=%s, wants_sms=%s, 
                wants_calls=%s, wants_direct_mail=%s, status=%s, updated_at = %s
        """
        upsert_data = []
        count = 0
        # Create a partial function to update the data sync stats
        partial_upsert_data_sync = partial(
            upsert_into_data_sync_table,
            connection=postgres_connection,
            dag_run_id=dag_run_id,
            entity_type='contact',
            status=SyncStatusEnum.PROCESSING.value,
        )
        for record in records:
            if "verified_data" in record and record["verified_data"] is not None:
                record["transformed"].update(record["verified_data"])

            data_tuple = generate_contact_tuple(record)
            upsert_data.append(data_tuple)
            count += 1
            if count % conf.get('MYSQL_INSERT_BATCH_SIZE') == 0:
                response = cursor.executemany(sql_upsert_query, upsert_data)
                logger.info(
                    f'{count} out of {len(upsert_data)} records upserted into contact table successfully!'
                )

                # Update data_sync_stats table status
                partial_upsert_data_sync(
                    processing_ts=records[count - 1]['processing_ts'],
                    records_count=count,
                    to_id=records[count - 1].get('id'),
                )

                upsert_data = []
                connection.commit()

        response = cursor.executemany(sql_upsert_query, upsert_data)
        logger.info(f' Total {count} records upserted into contact table successfully!')

        if len(upsert_data) > 0:
            to_id = records[-1]['id']

            # Update data_sync_stats table status
            partial_upsert_data_sync(
                processing_ts=records[count - 1]['processing_ts'], records_count=count, to_id=to_id
            )

        connection.commit()
        cursor.close()
    except mysql.connector.Error as error:
        logger.exception(f"Parameterized query failed due to connection error")
    except Exception as e:
        logger.exception(f'Exception while upserting into MySQL!')


def generate_contact_tuple(record):
    data_tuple = (
        record.get('transformed').get('external_id'),
        record.get('meta').get('company_id'),
        record.get('transformed').get('first_name'),
        record.get('transformed').get('last_name'),
        record.get('transformed').get('full_name'),
        record.get('transformed').get('phone_daytime'),
        record.get('transformed').get('phone_mobile'),
        record.get('transformed').get('email'),
        record.get('transformed').get('address1'),
        record.get('transformed').get('address2'),
        record.get('transformed').get('city'),
        record.get('transformed').get('state'),
        record.get('transformed').get('zip'),
        record.get('transformed').get('country'),
        record.get('transformed').get('notes'),
        record.get('transformed').get('want_emails'),
        record.get('transformed').get('want_sms'),
        record.get('transformed').get('want_calls'),
        record.get('transformed').get('want_direct_mail'),
        record.get('status'),
        record.get('transformed').get('first_name'),
        record.get('transformed').get('last_name'),
        record.get('transformed').get('full_name'),
        record.get('transformed').get('phone_daytime'),
        record.get('transformed').get('phone_mobile'),
        record.get('transformed').get('email'),
        record.get('transformed').get('address1'),
        record.get('transformed').get('address2'),
        record.get('transformed').get('city'),
        record.get('transformed').get('state'),
        record.get('transformed').get('zip'),
        record.get('transformed').get('country'),
        record.get('transformed').get('notes'),
        record.get('transformed').get('want_emails'),
        record.get('transformed').get('want_sms'),
        record.get('transformed').get('want_calls'),
        record.get('transformed').get('want_direct_mail'),
        record.get('status'),
        datetime.utcnow(),
    )
    return data_tuple


def mysql_insert_transactions(connection, postgres_connection, records: list, dag_run_id):
    try:
        cursor = connection.cursor(prepared=True)

        sql_upsert_query = """
            INSERT INTO `transaction`
            (external_id, company_id, external_contact_id, receipt_number, transacted_at, amount, is_paid)
            VALUES(%s, %s, %s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                external_contact_id = %s, receipt_number = %s, transacted_at = %s, 
                amount = %s, is_paid = %s, updated_at = %s
        """
        upsert_data = []
        count = 0

        # Create a partial function to update the data sync stats
        partial_upsert_data_sync = partial(
            upsert_into_data_sync_table,
            connection=postgres_connection,
            dag_run_id=dag_run_id,
            entity_type='transaction',
            status=SyncStatusEnum.PROCESSING.value,
        )
        for record in records:

            data_tuple = generate_transaction_tuple(record)
            upsert_data.append(data_tuple)
            count += 1
            if count % conf.get('MYSQL_INSERT_BATCH_SIZE') == 0:
                response = cursor.executemany(sql_upsert_query, upsert_data)
                logger.info(
                    f'{count} out of {len(upsert_data)} records upserted into transaction table successfully!'
                )

                # Update status in data_sync_stats
                partial_upsert_data_sync(
                    processing_ts=records[count - 1]['processing_ts'],
                    records_count=count,
                    to_id=records[count - 1].get('id'),
                )

                upsert_data = []
                connection.commit()

        response = cursor.executemany(sql_upsert_query, upsert_data)
        logger.info(f' Total {count} records upserted into transaction table successfully!')

        if len(upsert_data) > 0:
            partial_upsert_data_sync(
                processing_ts=records[count - 1]['processing_ts'],
                records_count=count,
                to_id=records[-1]['id'],
            )

        connection.commit()
        cursor.close()
    except mysql.connector.Error as error:
        logger.exception(f"Parameterized query failed due to connection error")
    except Exception as e:
        logger.exception(f'Exception while upserting into MySQL!')


def generate_transaction_tuple(record):
    data_tuple = (
        record.get('transformed').get('external_id'),
        record.get('meta').get('company_id'),
        record.get('transformed').get('external_contact_id'),
        record.get('transformed').get('receipt_number'),
        record.get('transformed').get('transacted_at'),
        record.get('transformed').get('amount'),
        record.get('transformed').get('is_paid'),
        record.get('transformed').get('external_contact_id'),
        record.get('transformed').get('receipt_number'),
        record.get('transformed').get('transacted_at'),
        record.get('transformed').get('amount'),
        record.get('transformed').get('is_paid'),
        datetime.utcnow(),
    )
    return data_tuple
