from data_pipeline import logger
from data_pipeline.db.update_stats_utils import upsert_data_upload_logs
from data_pipeline.utils.retry_on_exception import RETRY_COUNT, ERROR_MESSAGE
from data_pipeline.utils.datetime_utils import get_current_ts_string
from data_pipeline.utils.filename_utils import get_file_name


def log_stats(process_function):
    """
    Function to update data preprocessing logs in mysql

    Args:
        function

    Returns:
        function
    """

    def log_stats_function(self):
        logger.info(f"Starting Execution - {str(process_function)}")

        upsert_data_upload_logs(
            company_id=self.metadata.get('metadata').get('company_id'),
            mapper_used=self.metadata.get('metadata').get('workflow_system_name'),
            filename=get_file_name(self.metadata),
            workflow_system_used=self.metadata.get('metadata').get('workflow_system_id'),
            status=f"Starting {self.__class__.__name__}",
            updated_at=get_current_ts_string(),
        )

        data, stats = process_function(self)

        stats['company_id'] = self.metadata.get('metadata').get('company_id')
        stats['mapper_used'] = self.metadata.get('metadata').get('workflow_system_name')
        stats['filename'] = get_file_name(self.metadata)
        stats['workflow_system_used'] = self.metadata.get('metadata').get('workflow_system_id')
        stats['status'] = (f"Completed {self.__class__.__name__}",)
        stats['error_message'] = ERROR_MESSAGE
        stats['retry_count'] = RETRY_COUNT
        stats['updated_at'] = get_current_ts_string()

        upsert_data_upload_logs(**stats)

        logger.info(f"Execution Completed - {str(process_function)}")
        return data

    return log_stats_function
