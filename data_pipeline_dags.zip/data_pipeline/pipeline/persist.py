from retrying import retry
from .base import BaseStep
from bson import json_util
from data_pipeline.stats.decorator import log_stats
from data_pipeline.utils.retry_on_exception import retry_if_exception
from data_pipeline.utils.pipeline_constants import (
    EntityEnum,
    STOP_MAX_ATTEMPT_NUMBER,
    STOP_MAX_DELAY,
    WAIT_FIXED,
)
from data_pipeline.utils.datetime_utils import get_current_ts_string
from data_pipeline.config import conf
from data_pipeline import logger
from datetime import datetime
import psycopg2
import json


class PersistStep(BaseStep):
    """
    To store transformed data into Postgresql
    """

    def __init__(self, metadata, data):

        # Get the POSTGRESQL connection parameters from config
        postgresql_conf = conf.get('POSTGRESQL')
        host = postgresql_conf.get('host')
        port = postgresql_conf.get('port')
        username = postgresql_conf.get('user')
        password = postgresql_conf.get('password')
        database = postgresql_conf.get('database')

        # Connect to POSTGRESQL
        self.connection = psycopg2.connect(
            host=host, port=port, user=username, password=password, database=database
        )
        super().__init__(metadata, data)

    def insert_records(self, entity, records):
        """
        Function to bulk insert records in Postgresql table
        Args:
            entity (str): Name of the entity being processed (ex: customers, transactions)
            records (list): List of records to be inserted into the Postgresql table

        Returns:
            Response from the bulk insert statement
        """
        workflow_system = records[0].get('meta').get('workflow_system')
        insert_query = f"""
        INSERT INTO {entity}_{workflow_system}
                ( 
                raw, 
                transformed, 
                errors, 
                meta, 
                status, 
                external_id, 
                workflow_system,
                company_id, 
                input_file_name, 
                input_file_creation_ts, 
                processing_ts)
                VALUES
                (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        try:
            requests = []
            for record in records:
                rec = (
                    json.dumps(record.get('raw')),
                    json.dumps(record.get('transformed')),
                    json.dumps(record.get('errors')),
                    json.dumps(record.get('meta'), default=json_util.default),
                    record.get('status'),
                    record.get('transformed').get('external_id'),
                    record.get('meta').get('workflow_system'),
                    record.get('meta').get('company_id'),
                    record.get('meta').get('input_file_name'),
                    record.get('meta').get('input_file_creation_ts'),
                    record.get('meta').get('processing_ts'),
                )
                requests.append(rec)
            cursor = self.connection.cursor()
            result = cursor.executemany(insert_query, requests)
            self.connection.commit()
            return result
        except (Exception, psycopg2.Error) as e:
            logger.exception(f'Error occurred while inserting into Postgresql! {e}')

    def postgresql_batch_insert(self, entity):
        """
        Function to divide the records in batches and then bulk insert into Postgresql
        Args:
            entity (str): Name of the entity being processed (ex: customers, transactions)

        Returns:

        """
        count = 0
        total = len(self.data.get(entity))
        insert_batch_size = conf.get('POSTGRESQL_INSERT_BATCH_SIZE', 100000)
        logger.info(f'Entity - {entity}')
        # Insert Multiple records in PostgreSQL in batches
        for i in range((total + insert_batch_size - 1) // insert_batch_size):
            records = self.data.get(entity)[i * insert_batch_size : (i + 1) * insert_batch_size]
            self.insert_records(entity, records)
            count += len(records)
            logger.info(f'Inserting {count} out of {total} {entity} records in Postgresql!')

    @retry(
        stop_max_attempt_number=STOP_MAX_ATTEMPT_NUMBER,
        stop_max_delay=STOP_MAX_DELAY,
        wait_fixed=WAIT_FIXED,
        retry_on_exception=retry_if_exception,
    )
    @log_stats
    def process(self):
        """
        Function to save transformed data in Postgresql

        Args:

        Returns:
            data: json - Data (JSON format)
        """

        for entity in [EntityEnum.CONTACT.value, EntityEnum.TRANSACTION.value]:
            if self.data.get(entity):
                self.postgresql_batch_insert(entity)

        stats = {'ingester_completed_at': get_current_ts_string()}
        return self.data, stats
