from .base import BaseStep
from data_pipeline.stats.decorator import log_stats
from dateutil.parser import parse
from datetime import datetime
from data_pipeline.utils.pipeline_constants import EntityEnum
from data_pipeline.utils.filename_utils import get_file_name


class EnrichmentStep(BaseStep):
    """
    Add Features to transformed data
    """

    @log_stats
    def process(self):
        """
        Function to add features to JSON Data

        Args:

        Returns:
            data: json - Data (JSON format)
        """
        file_name = get_file_name(self.metadata)
        company_id = self.metadata.get('metadata').get('company_id')
        file_creation_ts = parse(self.metadata.get('metadata').get('file_creation_ts'))
        workflow_system_id = self.metadata.get('metadata').get('workflow_system_id')
        workflow_system_name = self.metadata.get('metadata').get('workflow_system_name')
        attributes = {
            'company_id': company_id,
            'workflow_system': workflow_system_name,
            'workflow_system_id': workflow_system_id,
            'input_file_name': file_name,
            'input_file_creation_ts': file_creation_ts,
            'processing_ts': datetime.utcnow(),
        }
        for entity in [EntityEnum.CONTACT.value, EntityEnum.TRANSACTION.value]:
            if self.data.get(entity):
                for data_obj in self.data.get(entity):
                    data_obj['meta'] = attributes
                    if data_obj['transformed']['external_id'] is not None:
                        data_obj['transformed'][
                            'external_id'
                        ] = f"""{company_id}|{workflow_system_id}|{entity}|{data_obj['transformed']['external_id']}"""
        stats = {}
        return self.data, stats
