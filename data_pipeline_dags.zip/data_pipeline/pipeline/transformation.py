from .base import BaseStep
from data_pipeline.utils.pipeline_constants import datatype_mapping
from data_pipeline.stats.decorator import log_stats
from data_pipeline.config import conf
from data_pipeline.utils.pipeline_constants import EntityEnum, StatusEnum
from importlib import import_module

# Do not remove the below imports. The methods imported below are used dynamically at runtime
from data_pipeline.utils.address import *
from data_pipeline.utils.email import *
from data_pipeline.utils.name import *
from data_pipeline.utils.phone_number import *
from data_pipeline.utils.boolean_utils import *
from data_pipeline.utils.commercial_utils import *
from data_pipeline.utils.datetime_utils import *

ERROR_COUNT = 0
CUSTOMER_ERROR_COUNT = 0
TRANSACTION_ERROR_COUNT = 0


def apply_rule(rule, function, converted_value, rule_name, record, output_record):
    # Check if rule to be applied has params
    if isinstance(rule, dict):
        given_params = rule.get(rule_name).get('params')
        params = {}

        literal_params = given_params.get('literal', {})
        column_params = given_params.get('input_column', {})
        output_column_params = given_params.get('output_column', {})

        # Check if literal params are present
        params.update(literal_params)

        # Check if column params are present
        params.update({key: record.get(value) for key, value in column_params.items()})

        # Check if output column params are present
        params.update(
            {key: output_record.get(value) for key, value in output_column_params.items()}
        )

        # Execute the rule with identified params
        converted_value = function(**params)
    else:
        converted_value = function(converted_value)
    return converted_value


def generate_output_record(record, rules, schema):
    """
    Utility function for implement standardization and validation functions while transforming a single record.

    Arguments:
        record: dict - input record
        rules: dict - Rules mapping for the input fields
        schema: dict - Schema mapping for the data set

    Returns:
        output_record: dict - dict of output fields
    """
    output_record = {'raw': record, 'transformed': {}, 'status': StatusEnum.VALID.value}
    errors = []
    global ERROR_COUNT
    # Iterate over all the fields present in the schema
    for output_column_name, mapping in schema.items():
        input_column_name = mapping.get('input_column')
        output_data_type = mapping.get('data_type')
        converted_value = None

        if input_column_name is not None:
            converted_value = record.get(input_column_name)

        if rules.get(output_column_name):

            # Iterate over rules to be applied to the input field value
            for rule in rules.get(output_column_name):
                try:
                    # Get the rule name to be applied
                    rule_name = rule if isinstance(rule, str) else list(rule.keys())[0]
                    # The if else condition below helps us to use system defined functions as rules
                    if '.' in rule_name:
                        sys_funcs = rule_name.rsplit('.', 1)
                        function = getattr(import_module(sys_funcs[0]), sys_funcs[-1])
                    else:
                        function = globals().get(rule_name, None)

                    # Check if the rule name is available
                    if function is not None:
                        converted_value = apply_rule(
                            rule,
                            function,
                            converted_value,
                            rule_name,
                            record,
                            output_record.get('transformed'),
                        )
                    else:
                        logger.exception(f'Invalid rule provided - {rule_name}')
                        errors.append(
                            {
                                'msg': 'Invalid rule provided',
                                'rule': rule,
                                'field': output_column_name,
                                'value': converted_value,
                            }
                        )
                        ERROR_COUNT += 1

                except Exception as e:
                    msg = f'Failed to apply rule {rule} on value "{converted_value}" while generating output column "{output_column_name}"'
                    logger.exception(msg)
                    output_record['status'] = StatusEnum.INVALID.value
                    errors.append(
                        {
                            'msg': f'Failed to apply rule - {str(e)}',
                            'rule': rule,
                            'field': output_column_name,
                            'value': converted_value,
                        }
                    )
                    ERROR_COUNT += 1
                    converted_value = None
                    break

        # Set default value given in the mapping file if transformed value is None
        converted_value = (
            mapping.get('default', None) if converted_value is None else converted_value
        )

        # Perform a type conversion and set the output column value
        try:

            if converted_value is not None:
                # Apply data type mapping to the converted value
                converted_value = datatype_mapping[output_data_type](str(converted_value))

                # Set the output value
                output_record['transformed'][output_column_name] = converted_value
        except Exception as e:
            logger.exception(
                f'Failed to perform data type conversion "{output_data_type}" on value "{converted_value}" while generating output column "{output_column_name}"'
            )
            output_record['status'] = StatusEnum.INVALID.value
            errors.append(
                {
                    'msg': f'Failed to perform data type conversion',
                    'data_type': output_data_type,
                    'field': output_column_name,
                    'value': converted_value,
                }
            )
            ERROR_COUNT += 1

        if errors:
            output_record['errors'] = errors

        # logger.debug(f'Input Column - {input_column_name} | Output Column - {output_column_name}
        # | Input Value - {record.get(input_column_name)} | Transformed Value - {converted_value}
        # | Output Value - {output_record.get(output_column_name)}')
    return output_record


def standardize(data, schema):
    """
    Adapter function for implementing standardization and validation functions while transforming the data.

    Arguments:
        data: list - list of input records
        schema: dict - Schema mapping for the data set

    Returns:
        output_data: list - dict of processed records
    """

    # Identify the rules to be applied to the individual fields
    rules = dict()
    rules.update({column_name: mapping.get('rules', '') for column_name, mapping in schema.items()})

    output_data = list()
    # Iterate over the input data
    for record in data:
        try:
            output_record = generate_output_record(record, rules, schema)
            output_data.append(output_record)
        except Exception as e:
            logger.exception(
                f'Exception occurred while generating output record.\nInput data - {record}'
            )
    return output_data


def perform_transformation(data, schema, file_names):
    response_data = []
    for file in file_names:
        file_name = file.replace('.json', '')
        if data.get(file_name) and schema.get(file_name):
            response_data = response_data + standardize(data.get(file_name), schema.get(file_name))
    return response_data


class CustomerTransformationStep(BaseStep):
    """
    To transform customer data
    """

    @log_stats
    def process(self):
        """
        Function to transform the customer data

        Args:

        Returns:
            data: dict - Data
        """
        global ERROR_COUNT, CUSTOMER_ERROR_COUNT, TRANSACTION_ERROR_COUNT
        ERROR_COUNT = 0
        CUSTOMER_ERROR_COUNT = 0
        self.data[EntityEnum.CONTACT.value] = perform_transformation(
            self.data.get(EntityEnum.CONTACT.value),
            self.metadata.get('schema').get(EntityEnum.CONTACT.value),
            conf.get('FILES').get(EntityEnum.CONTACT.value),
        )
        CUSTOMER_ERROR_COUNT = ERROR_COUNT
        stats = {}
        stats['customers_error_count'] = CUSTOMER_ERROR_COUNT
        return self.data, stats


class TransactionTransformationStep(BaseStep):
    """
    To transform transaction data
    """

    @log_stats
    def process(self):
        """
        Function to read and transform the transaction data

        Args:

        Returns:
            data: dict - Data
        """
        global ERROR_COUNT, CUSTOMER_ERROR_COUNT, TRANSACTION_ERROR_COUNT
        ERROR_COUNT = 0
        TRANSACTION_ERROR_COUNT = 0
        self.data[EntityEnum.TRANSACTION.value] = perform_transformation(
            self.data.get(EntityEnum.TRANSACTION.value),
            self.metadata.get('schema').get(EntityEnum.TRANSACTION.value),
            conf.get('FILES').get(EntityEnum.TRANSACTION.value),
        )
        TRANSACTION_ERROR_COUNT = ERROR_COUNT
        stats = {}
        stats['transactions_error_count'] = TRANSACTION_ERROR_COUNT
        return self.data, stats
