class BaseStep:
    """
    Base Class
    """

    def __init__(self, metadata, data):
        """
        Function to initialize the object with given parameters

        Args:
            metadata: dict - dict containing file paths and schema
            data: dict - dict containing data
        """
        self.metadata = metadata
        self.data = data
        pass

    def process(self):
        """
        Function to perform operation

        Abstract Method
        """
        pass
