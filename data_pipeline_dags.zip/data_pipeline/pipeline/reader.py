import json
from io import BytesIO
from zipfile import ZipFile
from .base import BaseStep
from data_pipeline.config import conf, get_s3_resource
from data_pipeline.stats.decorator import log_stats
from data_pipeline.utils.pipeline_constants import (
    EntityEnum,
    STOP_MAX_ATTEMPT_NUMBER,
    STOP_MAX_DELAY,
    WAIT_FIXED,
)
from data_pipeline import logger
from data_pipeline.utils.datetime_utils import get_current_ts_string
from retrying import retry
from data_pipeline.utils.retry_on_exception import retry_if_exception
from datetime import datetime


class ReaderStep(BaseStep):
    """
    Read zip file uploaded in s3 bucket
    """

    @retry(
        stop_max_attempt_number=STOP_MAX_ATTEMPT_NUMBER,
        stop_max_delay=STOP_MAX_DELAY,
        wait_fixed=WAIT_FIXED,
        retry_on_exception=retry_if_exception,
    )
    def read_file(self):
        """
        Function to read and return the data in JSON file

        Args:

        Returns:
            data: dict - Data
        """
        file_path = self.metadata.get('file_path').get('path')
        with open(file_path, 'r') as f:
            self.data = json.load(f)
            return self.data

    @retry(
        stop_max_attempt_number=STOP_MAX_ATTEMPT_NUMBER,
        stop_max_delay=STOP_MAX_DELAY,
        wait_fixed=WAIT_FIXED,
        retry_on_exception=retry_if_exception,
    )
    def read_s3_zip_file(self):
        # Initialize self.data
        self.data = {EntityEnum.CONTACT.value: {}, EntityEnum.TRANSACTION.value: {}}

        # Get the s3 bucket name and file_path
        file = self.metadata.get('file_path')
        bucket_name = file.get('bucket')
        file_path = file.get('path')
        print(file_path)
        # Create a buffer stream for the input file and read it
        zip_file_obj = get_s3_resource().Object(bucket_name=bucket_name, key=file_path)
        file_buffer = BytesIO(zip_file_obj.get()["Body"].read())
        z = ZipFile(file_buffer)

        # Read data files for Customer Entity
        customers_file_size = self.read_file_data(
            z,
            EntityEnum.CONTACT.value,
            conf.get('FILES').get(EntityEnum.CONTACT.value),
            self.metadata.get('schema').get(EntityEnum.CONTACT.value),
        )

        # Read data files for Transaction Entity
        transactions_file_size = self.read_file_data(
            z,
            EntityEnum.TRANSACTION.value,
            conf.get('FILES').get(EntityEnum.TRANSACTION.value),
            self.metadata.get('schema').get(EntityEnum.TRANSACTION.value),
        )
        z.close()
        return self.data, customers_file_size, transactions_file_size

    @retry(
        stop_max_attempt_number=STOP_MAX_ATTEMPT_NUMBER,
        stop_max_delay=STOP_MAX_DELAY,
        wait_fixed=WAIT_FIXED,
        retry_on_exception=retry_if_exception,
    )
    def read_zip_file(self):
        """
        Function to read and return the data from zip file

        Args:

        Returns:
            data: dict - Data
        """
        file_path = self.metadata.get('file_path').get('path')
        self.data = {EntityEnum.CONTACT.value: {}, EntityEnum.TRANSACTION.value: {}}

        with ZipFile(file_path, 'r') as archive:
            # Read data files for Customer Entity
            self.read_file_data(
                archive,
                EntityEnum.CONTACT.value,
                conf.get('FILES').get(EntityEnum.CONTACT.value),
                self.metadata.get('schema').get(EntityEnum.CONTACT.value),
            )

            # Read data files for Transaction Entity
            self.read_file_data(
                archive,
                EntityEnum.TRANSACTION.value,
                conf.get('FILES').get(EntityEnum.TRANSACTION.value),
                self.metadata.get('schema').get(EntityEnum.TRANSACTION.value),
            )
            archive.close()
        return self.data

    @retry(
        stop_max_attempt_number=STOP_MAX_ATTEMPT_NUMBER,
        stop_max_delay=STOP_MAX_DELAY,
        wait_fixed=WAIT_FIXED,
        retry_on_exception=retry_if_exception,
    )
    def read_file_data(self, archive, entity, files_list, schema):
        filesize = 0
        for fileName in files_list:
            if schema.get(fileName.replace('.json', '')):
                file_content = archive.read(fileName)
                filesize += archive.getinfo(fileName).file_size
                file_data = json.loads(file_content.decode())
                if file_data and file_data.get('data') and file_data.get('data').get('row'):
                    self.data[entity][fileName.replace('.json', '')] = file_data.get('data').get(
                        'row'
                    )
        return filesize

    @log_stats
    def process(self):
        """
        Function to read and return the data

        Args:

        Returns:
            data: dict - Data
        """
        from data_pipeline import config

        stats = {
            'created_at': config.stats_entry_created_at,
            'ingester_started_at': get_current_ts_string(),
        }

        self.read_s3_zip_file()
        customers_count = sum(
            map(
                lambda x: len(self.data[EntityEnum.CONTACT.value][x.replace('.json', '')]),
                self.data[EntityEnum.CONTACT.value],
            )
        )
        transactions_count = sum(
            map(
                lambda x: len(self.data[EntityEnum.TRANSACTION.value][x.replace('.json', '')]),
                self.data[EntityEnum.TRANSACTION.value],
            )
        )

        stats['customers_count'] = customers_count
        stats['transactions_count'] = transactions_count

        if customers_count <= 0 and transactions_count <= 0:
            logger.error("Error occurred while reading file")
        else:
            logger.info('Input file data read successfully!')
        return self.data, stats
