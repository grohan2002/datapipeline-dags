import logging
import data_pipeline.config

# Logger
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)
