import re
import probablepeople

"""
Module:
    name_cleaner
    
    To extract and clean all the emails from a string
"""

remove_numbers_regex = re.compile("[0-9]")
remove_symbols_regex = re.compile(r"[^\w|'|\-|\s|&]")
split_name_regex = re.compile(r'&|\s')

FIRST = "first"
LAST = "last"
FULL = "full"


def get_company_name(input_value, commercial):
    """
    Function to get company name if the record type is commercial
    Args:
        input_value: str
        commercial: boolean

    Returns:

    """
    if commercial:
        return input_value
    return None


def get_first_name(full_name):
    """
    Function to get first name

    Args:
        full_name: string - full name in string

    Returns:
        string - first name from full name
    """

    split_names = split_name_regex.split(full_name)
    if split_names:
        split_first_names = split_names[0].split(" and ")
        if len(split_first_names) > 0:
            return split_first_names[0]


def get_last_name(full_name):
    """
    Function to get last name

    Args:
        full_name: string - full name in string

    Returns:
        string - last name from full name
    """

    split_names = full_name.split(" ")
    if split_names:
        return split_names[-1]


def get_full_name(first_name, last_name):
    """

    Args:
        first_name: str
        last_name: str

    Returns: str

    """
    return f'{first_name} {last_name}'


def clean_name(person_name, name_type=FULL):
    """
    Function to clean the person names

    Args:
        person_name: string - person name in string

    Returns:
        string - cleaned person name
    """
    if person_name and person_name != "&":
        person_name = remove_symbols_regex.sub(
            ' ', remove_numbers_regex.sub('', person_name).replace('.', '')
        )
        person_name = person_name.rstrip("-")

        # Keep unique
        split_name = person_name.split()
        unique_values_in_name = []
        for val in split_name:
            if val not in unique_values_in_name:
                unique_values_in_name.append(val)

        # Join Unique List
        person_name = ' '.join(unique_values_in_name)

        # Remove whitespaces and capitalize the words
        person_name = person_name.strip()

        if name_type == FIRST:
            return get_first_name(person_name)
        elif name_type == LAST:
            return get_last_name(person_name)
        elif name_type == FULL:
            return person_name.title()

    return None


def parse_first_name_from_full_name(full_name):
    """
    Function to Pull the first name from a full name field in either
    'First Last' or 'Last, First' format.

    Args:
        full_name: string - full name in string

    Returns:
        string - first name from full name 
    """
    if full_name:
        parsed_name = probablepeople.parse(full_name)
        for parsed_item in parsed_name:
            if parsed_item[1] == "GivenName":
                if parsed_item[0]:
                    return parsed_item[0].title()
                else:
                    return None
    return None


def parse_last_name_from_full_name(full_name):
    """
    Function to Pull the last name from a full name field in either 
    'First Last' or 'Last, First' format.
    
    Args:
        full_name: string - full name
        
    Returns:
        string - last name from full name
    """
    if full_name:
        parsed_name = probablepeople.parse(full_name)
        last_name = ""
        for parsed_item in parsed_name:
            if parsed_item[1] == "Surname":
                if parsed_item[0]:
                    last_name = parsed_item[0].title()
        if last_name:
            return last_name
    return None
