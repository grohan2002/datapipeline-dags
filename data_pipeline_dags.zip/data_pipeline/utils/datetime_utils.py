from datetime import datetime
from dateutil.parser import parse
from dateutil.tz import tzutc


def convert_datetime(input_value):
    """
    Function to convert a datetime string

    Args:
        input_value: string - datetime string

    Returns:
        date: string - parsed datetime string
    """
    if input_value:
        return parse(input_value)
    return None


def generate_timestamp():
    """
    Function to get current datetime in UTC

    Args:
        
    Returns:
        datetime: datetime - current datetime in UTC
    """
    return datetime.utcnow()


def format_processing_ts(processing_ts):
    processing_ts_obj = datetime.strptime(processing_ts, "%Y-%m-%dT%H:%M:%S.%fZ")
    processing_ts_obj = processing_ts_obj.replace(microsecond=0)
    return processing_ts_obj


def get_transacted_at(transacted_at, job_completed_on):
    """
    Function to parse transaction time

    Args:
        transacted_at: string - transaction datetime
        job_completed_on: string - job completion datetime

    Returns:
        datetime: string - parsed transaction or job completion datetime
    """
    if transacted_at:
        return parse(transacted_at)
    elif job_completed_on:
        return parse(job_completed_on)
    return None


def get_current_ts_string():
    """
    Function to get current datetime in string format

    Args:
    
    Returns:
        Current Datetime in string format
    """
    current_date_time = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    return current_date_time


def get_current_ts_object():
    """
    Function to get current datetime object

    Args:

    Returns:
        Current Datetime object
    """
    current_date_time = datetime.utcnow()
    return current_date_time
