import json
from dateutil.parser import parse


def get_commercial_service_titan(input_value):
    """
    Function to determine the where the record is commercial or not
    Args:
        input_value: str

    Returns: bool

    """
    if (str(input_value) == '1') or ('commercial' in str(input_value).lower()):
        return True
    return False


def get_commercial_successware21_asp(input_value):
    """
    Function to determine the where the record is commercial or not
    Args:
        input_value: str

    Returns: bool

    """
    if input_value.upper() in ['BUS', 'COM']:
        return True
    return False


def get_in_contract(contract_start_date):
    """
    Function to determine if the customer is in_contract or not
    Args:
        contract_start_date: date

    Returns: bool
    """
    return bool(contract_start_date)


def get_contract_end_date(has_active_membership, memberships):
    """
    Function to get contract end date from memberships list
    Args:
        has_active_membership: bool
        memberships: list

    Returns: date

    """
    if has_active_membership:
        memberships = active_memberships(memberships)
        if memberships:
            end_date = memberships[-1].get('to')
            if end_date and parse(end_date):
                return parse(end_date)
    return None


def get_contract_start_date(has_active_membership, memberships):
    """
    Function to get contract start date from memberships list
    Args:
        has_active_membership: bool
        memberships: list

    Returns: date

    """
    if has_active_membership:
        memberships = active_memberships(memberships)
        if memberships:
            start_date = memberships[-1].get('from')
            if start_date and parse(start_date):
                return parse(start_date)
    return None


def active_memberships(memberships):
    """
    Function to get all the active memberships
    Args:
        memberships: list

    Returns: list

    """
    if not memberships:
        return None
    memberships = json.loads(memberships)
    response = [membership for membership in memberships if membership.get('type').get('active')]
    return response
