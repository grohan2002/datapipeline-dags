from data_pipeline.utils.pipeline_constants import KEEP_ONLY_DIGITS_REGEX


"""
Module:
    PhoneNumberCleaner

    To clean the phone numbers
"""

MOBILE = "mobile"
DAYTIME = "daytime"


def validate_length(phone_number, phone_type):
    """
    Function to check the length of phone number

    Args:
        phone_number: string - Phone Number
        phone_type: string - mobile or daytime

    Returns:
        boolean: True if valid phone number else False
    """
    if phone_type == DAYTIME and (len(phone_number) == 7 or len(phone_number) >= 10):
        return True
    elif phone_type == MOBILE and len(phone_number) >= 10:
        return True
    return False


def pad_phone_number(phone_number, area_code):
    """
    Function to pad if phone number requires padding based on length

    Args:
        phone_number: string - Phone Number
        area_code: string - Area Code

    Returns:
        phone_number: string - Phone Number
    """
    if len(phone_number) == 7:
        return f'{area_code}{phone_number}'
    return phone_number


def clean_phone_number(phone_number, phone_type=MOBILE, area_code=''):
    """
    Function to clean phone number

    Args:
        phone_number: string - Phone Number
        phone_type: string - Phone type Mobile or Daytime
        
    Returns:
        phone_number: string - Phone Number
    """
    if phone_number:
        phone_number = KEEP_ONLY_DIGITS_REGEX.sub('', phone_number)
        if validate_length(phone_number, phone_type):
            if phone_type == DAYTIME:
                phone_number = pad_phone_number(phone_number, area_code)
            extracted_phone_number = (
                phone_number[:10] if len(phone_number) > 11 else phone_number[-10:]
            )
            return extracted_phone_number
    return None
