import os


def get_file_name(metadata: dict):
    """
    Function to extract file name from file path
    
    Args:
        metadata: Dictionary containing file path
    
    Returns: 
        file_name: Name of the file from file path
    """
    filename = os.path.basename(metadata.get('file_path').get('path'))
    return filename
