import re
from enum import Enum
import psycopg2

EXPECTED_BOOLEAN_VALUES = ['TRUE', '1', 'Y', 'YES']

datatype_mapping = {'string': str, 'int': int, 'float': float, 'boolean': bool, 'date': str}

KEEP_ONLY_DIGITS_REGEX = re.compile(r'[^0-9]')
KEEP_ONLY_ALPHABETS_REGEX = re.compile(r'[^a-zA-Z]')


class EntityEnum(Enum):
    CONTACT = 'contacts'
    TRANSACTION = 'transactions'


class StatusEnum(Enum):
    VALID = 'VALID'
    INVALID = 'INVALID'


class SyncStatusEnum(Enum):
    STARTED = 'Sync Started'
    PROCESSING = 'Syncing'
    COMPLETED = 'Sync Completed'
    NO_DATA = 'No Data to Sync'


# Exceptions which should be retried
EXCEPTIONS_TO_RETRY = (IOError, Exception, psycopg2.Error)
# Parameters to set while retrying
STOP_MAX_ATTEMPT_NUMBER = 3
STOP_MAX_DELAY = 100000
WAIT_FIXED = 20000
