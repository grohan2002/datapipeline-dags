from data_pipeline.utils.pipeline_constants import *

RETRY_COUNT = 0
ERROR_MESSAGE = ""


def retry_if_exception(exception):
    """
    Function to retry process if exception occurs

    Args:
        Exceptions

    Returns:
        func
    """
    if isinstance(exception, EXCEPTIONS_TO_RETRY):
        global RETRY_COUNT, ERROR_MESSAGE
        RETRY_COUNT += 1
        ERROR_MESSAGE = 'Exception while reading file'
    return isinstance(exception, EXCEPTIONS_TO_RETRY)
