import re
import pycountry
import usaddress
from data_pipeline import logger
from data_pipeline.utils.pipeline_constants import KEEP_ONLY_ALPHABETS_REGEX

"""
Module:
    Address_Cleaner

    To clean the address fields
"""

us_postal_code_regex = re.compile(r'.*(\d{5}(\-\d{4})?)$')
ca_postal_code_regex = re.compile(r'^[ABCEGHJKLMNPRSTVXY]{1}\d{1}[A-Z]{1} *\d{1}[A-Z]{1}\d{1}$')
city_name_regex = re.compile(r"[^a-z|\.|-|\s]")
street_address_regex = re.compile(r"[\d+]")
remove_apt_variation_regex = re.compile(r"\bapt\b|\bunit\b|#")
preprocess_address_regex = re.compile(r"#")


def clean_postal_code(postal_code, country_code='US'):
    """
    Function to clean the postal code

    Args:
        postal_code: string - postal code of the country
        country_code: string - country code default = US

    Returns:
        postal_code: string
    """
    if postal_code:
        postal_code = postal_code.strip()
        if country_code == "US":
            if us_postal_code_regex.search(postal_code.upper()):
                return postal_code
        elif country_code == "CA":
            if ca_postal_code_regex.search(postal_code.upper()):
                return postal_code
    return None


def check_if_valid_street_address(street_address):
    """
    Function to check if the string is a valid street address using house number

    Args:
        street_address: string - street address

    Returns - 
        boolean: True if valid else False
    """
    if street_address:
        parsed_address = usaddress.parse(street_address)
        is_valid = False
        for address_item in parsed_address:
            if address_item[1] == "AddressNumber":
                address_value = address_item[0]
                if address_value:
                    is_valid = True
                    break
        return is_valid
    return False


def check_if_valid_postbox_number(postal_address):
    """
    Function to check if the string is a valid postal address

    Args:
        postal_address: string - postal address

    Returns:
        boolean: True if valid else False
    """
    if postal_address:
        parsed_address = usaddress.parse(postal_address)
        is_valid = False
        for address_item in parsed_address:
            if address_item[1] == "USPSBoxType":
                address_val = address_item[0]
                if address_val:
                    is_valid = True
                    break
        return is_valid
    return False


def find_index_of_apt_variation(address):
    """
    Function to check if the apt, unit, or # is present in the string 
    and return an index of the staring point
    
    Args:
        address: string - address

    Returns:
        index: int - index of matching position
    """
    if address:
        match = remove_apt_variation_regex.search(address.lower(), re.IGNORECASE)
        if match is not None:
            return match.start()
    return None


def preprocess_address(address):
    """
    Function to get pre-processed address

    Args:
        address: string - address

    Returns:
        address: string - preprocessed address
    """
    if address:
        match = preprocess_address_regex.search(address.lower(), re.IGNORECASE)
        if match is not None:
            return address[: match.start()].strip()
        else:
            return address
    return None


def clean_street_address(street_address):
    """
    Function to clean the street address

    Args:
        street_address: string - street address

    Returns:
        street_address: string - cleaned street address
    """
    if street_address and street_address_regex.search(street_address):
        return street_address
    return None


def clean_city(city):
    """
    Function to clean the city

    Args:
        city: string - city

    Returns:
        city: string - cleaned city
    """
    if city:
        return city_name_regex.sub('', city.lower())
    return None


def clean_short_region_name(region, country_code='US'):
    """
    Function to return the short code for the region if it is found, nil if 
    the region is not found.

    Args:
        region: string - region 
        country_code: string - country code default US

    Returns:
        region_code: string - short region code for the region
    """
    if region:
        region = KEEP_ONLY_ALPHABETS_REGEX.sub('', region)
        if len(region) == 2:
            region_code = f'{country_code}-{region.upper()}'
            try:
                region_info = pycountry.subdivisions.lookup(region_code)
                if region_info:
                    return region
            except Exception as e:
                logger.exception(
                    f'Failed to fetch short region name from pycountry library for input - {region}'
                )
        else:
            try:
                region_info = pycountry.subdivisions.lookup(region.title())
                if region_info:
                    region_code = region_info.code
                    region_code = region_code.replace(f'{country_code}-', '')
                    return region_code
            except Exception as e:
                logger.exception(
                    f'Failed to fetch short region name from pycountry library for input - {region}'
                )
    return None


def clean_long_region_name(region, country_code='US'):
    """
    Function To return the long code for the region if it is found, nil if 
    the region is not found.

    Args:
        region: string - region

    Returns:
        region: string - long code for the region
    """
    if region:
        region = KEEP_ONLY_ALPHABETS_REGEX.sub('', region)
        region_code = region.title()
        if len(region) == 2:
            region_code = f'{country_code}-{region.upper()}'
        try:
            region_info = pycountry.subdivisions.lookup(region_code)
            if region_info:
                return region_info.name
        except Exception as e:
            logger.exception(
                f'Failed to fetch long region name from pycountry library for input - {region}'
            )
    return None
