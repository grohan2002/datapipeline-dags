from data_pipeline.utils.pipeline_constants import EXPECTED_BOOLEAN_VALUES
from data_pipeline import logger


def check_boolean(input_value, negate='False'):
    """
    Function to process boolean values from string format

    Args:
        input_value: string - boolean values in string format
        negate: string  - negate default False

    Returns:
        response: boolean
    """
    response = False
    if input_value and str(input_value).upper() in EXPECTED_BOOLEAN_VALUES:
        response = True
    return response if negate == 'False' else not response


def check_is_paid(posted: str, balance: float):
    """
    Function to process input column values to determine if the amount has 
    been paid

    Args:
        posted: str
        balance: float

    Returns:
        boolean: True
    """
    return check_boolean(posted) or balance == 0.0
