import re

"""
Module:
    EmailCleaner
    
    To extract and clean all the emails from a string
"""

email_separator_regex = re.compile(r'[\w\.-]+@[\w\.-]+')


def clean_email(data_string):
    """
    Function to return an email address, if multiple emails are there just return
    the first one, else return nil

    Args:
        data_string: string - email string

    Returns:
        email: string - first email string
    """
    if data_string:
        extracted_emails = email_separator_regex.findall(data_string.strip().lower())
        if extracted_emails:
            return extracted_emails[0]
    return None
