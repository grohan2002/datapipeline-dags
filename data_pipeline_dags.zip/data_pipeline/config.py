import os
import sys
import json
import boto3
import logging.config
from typing import Dict, Tuple, Any
from airflow.models import Variable
from airflow.hooks.base_hook import BaseHook

WORKFLOW_SYSTEM_SCHEMA_FILE_PATH_LITERAL = (
    "{environment_name}/config/workflow_systems/{workflow_system_name}.json"
)
COMPANY_SCHEMA_FILE_PATH_LITERAL = "{environment_name}/config/companies/{company_id}/mapping.json"

_s3_client = None
_s3_resource = None

stats_entry_created_at = ''
ID: int = 0
dag_run_id = ''


def get_s3_client():
    global _s3_client
    if _s3_client is None:
        _s3_client = boto3.client(
            's3',
            aws_access_key_id=conf.get('AWS_LOGIN'),
            aws_secret_access_key=conf.get('AWS_PASSWORD'),
        )
    return _s3_client


def get_s3_resource():
    global _s3_resource
    if _s3_resource is None:
        _s3_resource = boto3.resource(
            's3',
            aws_access_key_id=conf.get('AWS_LOGIN'),
            aws_secret_access_key=conf.get('AWS_PASSWORD'),
        )
    return _s3_resource


def init_config() -> Dict:
    """Initialize Application Config and Logging."""
    try:

        # s3 bucket name where the schema mapping configurations and the input data files would be put
        bucket_name = Variable.get('S3_DATA_BUCKET_NAME', default_var=None)
        aws_conn_id = Variable.get('AWS_CONNECTION_NAME', default_var='aws_default')

        aws_connection = BaseHook.get_connection(aws_conn_id)
        aws_login = aws_connection.login
        aws_password = aws_connection.password

        # Load configuration
        config_file_path = Variable.get('CONFIG_FILE_PATH', default_var=None)

        config_stream = boto3.client(
            's3', aws_access_key_id=aws_login, aws_secret_access_key=aws_password
        ).get_object(Bucket=bucket_name, Key=config_file_path)
        config = json.loads(config_stream.get('Body').read().decode('UTF-8'))

        # Initialize Logging Config
        logging_config = config.get('LOGGING', {})
        logging.config.dictConfig(logging_config)

        logger = logging.getLogger(__name__)
        logger.info('Application config loaded.')

        config.update(
            {
                'BUCKET_NAME': bucket_name,
                'ENVIRONMENT_NAME': Variable.get('ENVIRONMENT_NAME', default_var=None),
                'AWS_CONN_ID': aws_conn_id,
                'SQS_QUEUE_URL': Variable.get('SQS_QUEUE_URL', default_var=None),
                'SQS_SYNC_VERIFIED_DATA_QUEUE_URL': Variable.get(
                    'SQS_SYNC_VERIFIED_DATA_QUEUE_URL', default_var=None
                ),
                'AWS_CONNECTION': aws_connection,
                'AWS_LOGIN': aws_login,
                'AWS_PASSWORD': aws_password,
            }
        )

        return config
    except Exception as e:
        # Todo: Fix-me: Mock the global call of the init_config function
        if os.getenv('DATA_PIPELINE_TEST', False):
            return {}

        print('Unable to load application config {}'.format(e))
        import traceback

        traceback.print_exc()
        sys.exit()


conf = init_config()


def read_mapping_config(workflow_system_name: str, company_id: int):
    """
    Function to read schema mapping files from s3 location
    Args:
        workflow_system_name (str):
        company_id (int):

    Returns (dict): Returns the merged schema mapping output of workflow_system schema and company specific schema

    """
    workflow_schema = get_workflow_schema(workflow_system_name)
    try:
        company_schema = get_company_schema(company_id)
        if company_schema:
            effective_schema = get_effective_schema(workflow_schema, company_schema)
            return effective_schema
    except:
        logging.exception(
            'Error occurred while merging company specific schema mapping with workflow system schema mapping'
        )
    return workflow_schema


def get_workflow_schema(workflow_system_name: str):
    """
    Function to read workflow schema mapping from s3 location
    Args:
        workflow_system_name (str):

    Returns (dict):

    """
    # Read the Workflow System Schema Mapping file
    workflow_mapping_file_path = WORKFLOW_SYSTEM_SCHEMA_FILE_PATH_LITERAL.format(
        environment_name=conf.get('ENVIRONMENT_NAME', None),
        workflow_system_name=workflow_system_name,
    )
    workflow_mapping_stream = get_s3_client().get_object(
        Bucket=conf.get('BUCKET_NAME', None), Key=workflow_mapping_file_path
    )
    workflow_schema = json.loads(workflow_mapping_stream.get('Body').read().decode('UTF-8'))
    return workflow_schema


def get_company_schema(company_id: int):
    """
    Function to read company specific mapping file from s3 location
    Args:
        company_id (int):

    Returns (dict):

    """
    # Read the Company specific mapping file
    company_mapping_file_path = COMPANY_SCHEMA_FILE_PATH_LITERAL.format(
        environment_name=conf.get('ENVIRONMENT_NAME', None), company_id=company_id
    )
    company_mapping_stream = get_s3_client().get_object(
        Bucket=conf.get('BUCKET_NAME', None), Key=company_mapping_file_path
    )
    if company_mapping_stream:
        company_schema = json.loads(company_mapping_stream.get('Body').read().decode('UTF-8'))
        return company_schema
    return None


def get_effective_schema(workflow_schema: dict, company_schema: dict):
    """
    Function to override the workflow system schema with company specific mapping schema
    Args:
        workflow_schema (dict):
        company_schema (dict):

    Returns (dict):

    """
    # Merge the company specific mapping override with workflow system schema
    for entity, files in workflow_schema.items():
        if company_schema.get(entity):
            for file_name, file_schema in files.items():
                if company_schema.get(entity).get(file_name):
                    file_schema.update(company_schema.get(entity).get(file_name))

    return workflow_schema


def get(keys: Tuple[str], default_value: Any = None):
    """
    Get a value from nested config (dict).

    Args:
        keys: Tuple[str]
            Represents list of keys to traverse in the config
        default_value:
            Return this value if value is not found in config

    Returns:
        Any
            Return value for the requested keys
    """
    if not conf:
        print('Application config is not loaded')
        sys.exit()

    if isinstance(keys, str):
        return conf.get(keys, default_value)

    data = conf
    for key in keys:
        data = data.get(key, {})

    return data or default_value
